module.exports = {
  angular: ['angular/*'],
  html: ['html/*'],
  tmp: ['.tmp']
};
